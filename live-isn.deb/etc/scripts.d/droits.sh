#!/bin/sh
chmod 1777 /run/shm
chmod 1777 /tmp
chmod 1777 /var/tmp
