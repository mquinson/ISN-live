#!/bin/sh
/sbin/depmod -ae